# My Personal Portfolio

You can see my recent projects here in this portfolio as well as links to contact information, Resume, Github repos and Linkedin. I used github pages to host most of the static projects. 

I used HTML5 / CSS3,Twitter Bootstrap for column grid sizing and modals, jQuery and JavaScript for animations on this webpage.
Click each project image to view descriptions and links to each project's website and github code repo.
