var HTMLheaderName = '<h1 class="spacing head flex-item">%data%</h1>';
var HTMLheaderRole = '<p class="white-text centerSmall">%data%</p><hr>';

var HTMLcontactGeneric = '<li class="flex-item"><span class="orange-text">%contact%</span><span class="white-text">%data%</span></li>';
var HTMLmobile = '<li class="flex-item"><span class="orange-text">mobile : </span><span class="white-text">%data%</span></li>';
var HTMLemail = '<li class="flex-item"><span class="orange-text">email : </span><span class="white-text">%data%</span></li>';
var HTMLtwitter = '<li class="flex-item"><span class="orange-text">twitter : </span><span class="white-text">%data%</span></li>';
var HTMLgithub = '<li class="flex-item"><span class="orange-text">github : </span><span class="white-text">%data%</span></li>';
var HTMLblog = '<li class="flex-item"><span class="orange-text">blog : </span><span class="white-text">%data%</span></li>';
var HTMLlocation = '<li class="flex-item"><span class="orange-text">location : </span><span class="white-text">%data%</span></li>';

var HTMLfooterMobile = '<li class="flex-item"><a href="tel:%data%" class="fa fa-phone fa-3x"></a> Phone</li>';
var HTMLfooterEmail = '<li class="flex-item"><a href="mailto:%data%" target="_blank" class="fa fa-envelope fa-3x"></a> E-mail</li>';
var HTMLfooterGithub = '<li class="flex-item"><a href="http://github.com/%data%" target="_blank" class="fa fa-github fa-3x"></a> Github</li>';
var HTMLfooterLinkedin = '<li class="flex-item"><a href="%data%" target="_blank" class="fa fa-linkedin fa-3x"></a> LinkedIn</li>';

var HTMLbioPic = '<img src="%data%" class="biopic">';
var HTMLwelcomeMsg = '<span class="welcome-message">%data%</span><br>';

var HTMLskillsStart = '<h3 id="skills-h3">Skills at a Glance:</h3><ul id="skills" class="flex-box"></ul>';
var HTMLskills = '<li class="flex-item"><span class="white-text">%data%</span></li>';

var HTMLworkStart = '<div class="work-entry"></div>';
var HTMLworkEmployer = '<p class="blue-text"> %data%</p></a>';
var HTMLworkTitle = '<a href="#"><span>%data%</span>';
var HTMLworkDates = '<div class="date-text hideFirst">%data%</div>';
var HTMLworkLocation = '<div class="location-text hideFirst">%data%</div>';
var HTMLworkDescription = '<p class="hideFirst">%data%<br><br></p>';

var HTMLprojectStart = '<div class="project-entry"></div>';
var HTMLprojectTitle = '<a href="#">%data%</a>';
var HTMLprojectDates = '<div class="date-text hideFirstPortfolio">%data%</div>';
var HTMLprojectDescription = '<p class="hideFirstPortfolio"><br>%data%</p>';
var HTMLprojectImage = '<img src="%data%" class="projectImage hideFirstPortfolio">';

var HTMLschoolStart = '<div class="education-entry"></div>';
var HTMLschoolName = '<a href="#">%data%';
var HTMLschoolDegree = ' - %data%</a>';
var HTMLschoolDates = '<div class="date-text">%data%</div>';
var HTMLschoolLocation = '<div class="location-text">%data%</div>';
var HTMLschoolMajor = '<h3 class="blue-text"><em>%data%</em></h3>';

var HTMLonlineClasses = '<br><br><h3><strong>ONLINE CLASSES</strong></h3><br>';
var HTMLonlineTitle = '<h3>%data%';
var HTMLonlineSchool = ' - %data%</h3>';
var HTMLonlineDates = '<div class="date-text">%data%</div>';
var HTMLonlineURL = '%data%';