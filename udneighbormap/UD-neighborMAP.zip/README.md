# Los Angeles Attractions Map

Udacity Front-end nanodegree project #5 Neighborhood Map. Uses google maps API to show Los Angeles attractions.
Displays current weather in L.A. from openweather API, and wikipedia API summaries for each attractions.
Has list view of attractions that when clicked show markers in the generated map.
